export class signUp{
    streetName:string;
    areaName:string;
    areaLocation:string;
    postCode:string;
    

    constructor(streetName,areaName,areaLocation,postCode){
        this.streetName=streetName;
        this.areaName=areaName;
        this.areaLocation= areaLocation;
        this.postCode =postCode;
    }
}