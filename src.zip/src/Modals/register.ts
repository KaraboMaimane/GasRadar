export interface User{
    Username:string;
    email:string;
    password:string;
    
}